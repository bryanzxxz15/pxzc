﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class ForgotPassword : Form
    {
        public ForgotPassword()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Check if the email textbox is empty
                if (string.IsNullOrWhiteSpace(emailText.Text))
                {
                    MessageBox.Show("Please enter your email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Connect to the database
                using (SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus Laptop\Documents\CafeDataBase.mdf"";Integrated Security=True;Connect Timeout=30"))
                {
                    connect.Open();

                    // Query to check if the email exists
                    string query = "SELECT email FROM users WHERE email = @Email";
                    using (SqlCommand cmd = new SqlCommand(query, connect))
                    {
                        cmd.Parameters.AddWithValue("@Email", emailText.Text.Trim());

                        // Execute query
                        SqlDataReader reader = cmd.ExecuteReader();

                        if (reader.HasRows)
                        {
                            reader.Read();
                            string userEmail = reader["email"].ToString();

                            // Show a MessageBox with options
                            DialogResult result = MessageBox.Show(
                                "Do you want to generate a temporary password, or change your password?",
                                "Choose an Option",
                                MessageBoxButtons.YesNoCancel,
                                MessageBoxIcon.Question
                            );

                            if (result == DialogResult.Yes) // User chose to generate a temporary password
                            {
                                string tempPassword = GenerateTemporaryPassword();

                                // Update the user's password in the database with the temporary password
                                UpdatePasswordInDatabase(userEmail, tempPassword);

                                // Display the temporary password in a MessageBox
                                MessageBox.Show($"Your temporary password is: {tempPassword}", "Temporary Password", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else if (result == DialogResult.No) // User chose to change the password
                            {
                                // Prompt the user to enter a new password
                                string newPassword = PromptForNewPassword();

                                if (!string.IsNullOrEmpty(newPassword))
                                {
                                    // Update the password in the database
                                    UpdatePasswordInDatabase(userEmail, newPassword);

                                    MessageBox.Show("Your password has been successfully changed.", "Password Changed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    MessageBox.Show("Password change canceled.", "Canceled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                
                            }
                        }
                        else
                        {
                            MessageBox.Show("This email is not registered.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Handle exceptions
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string PromptForNewPassword()
        {
            // Create a new form to prompt the user for a new password
            using (Form inputForm = new Form())
            {
                inputForm.Width = 400;
                inputForm.Height = 150;
                inputForm.Text = "Enter New Password";

                // Create the label and text box for password input
                Label label = new Label() { Left = 10, Top = 20, Text = "New Password:" };
                TextBox textBox = new TextBox() { Left = 120, Top = 20, Width = 200, PasswordChar = '*' };

                // Create OK and Cancel buttons
                Button okButton = new Button() { Text = "OK", Left = 150, Width = 80, Top = 50 };
                Button cancelButton = new Button() { Text = "Cancel", Left = 240, Width = 80, Top = 50 };

                // Set button behaviors
                okButton.DialogResult = DialogResult.OK;
                cancelButton.DialogResult = DialogResult.Cancel;

                // Add controls to the form
                inputForm.Controls.Add(label);
                inputForm.Controls.Add(textBox);
                inputForm.Controls.Add(okButton);
                inputForm.Controls.Add(cancelButton);

                // Make the form respond to OK and Cancel buttons
                inputForm.AcceptButton = okButton;
                inputForm.CancelButton = cancelButton;

                // Show the form and check if the user pressed OK
                if (inputForm.ShowDialog() == DialogResult.OK)
                {
                    // If OK is pressed, return the entered password
                    return textBox.Text;
                }
            }

            // If Cancel is pressed, return null
            return null;
        }


        // Method to generate a random temporary password
        private string GenerateTemporaryPassword()
        {
            var random = new Random();
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var password = new char[8];  // Length of the temporary password (e.g., 8 characters)
            for (int i = 0; i < password.Length; i++)
            {
                password[i] = chars[random.Next(chars.Length)];
            }
            return new string(password);
        }

        // Method to update the user's password in the database
        private void UpdatePasswordInDatabase(string email, string tempPassword)
        {
            try
            {
                SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus Laptop\Documents\CafeDataBase.mdf"";Integrated Security=True;Connect Timeout=30");

                {
                    connect.Open();

                    string updateQuery = "UPDATE users SET password = @Password WHERE email = @Email";
                    using (SqlCommand cmd = new SqlCommand(updateQuery, connect))
                    {
                        cmd.Parameters.AddWithValue("@Password", tempPassword);
                        cmd.Parameters.AddWithValue("@Email", email);

                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while updating the password: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();

            // Open the Login form (Form1)
            Form1 loginForm = new Form1();
            loginForm.Show();
        }

        private void emailText_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
