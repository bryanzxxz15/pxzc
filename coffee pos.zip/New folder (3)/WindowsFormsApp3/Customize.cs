﻿    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp3
{
    public partial class Customize : Form
    {
        public string sugarLevel;
        public string milkChoice;
        public string customInstructions;
        public int addShot = 0;
        public string DineInOrTakeout;
        public decimal basePrice; // Base price of the drink
        public decimal additionalCost = 0;
        public int quantityy = 0;
        public decimal totalPrice;

        public Customize()
        {
            InitializeComponent();
        }
        public Customize(decimal price)
        {
            InitializeComponent();
            this.basePrice = price; // Set the base price passed from the Order form

        }
        private void UpdateAdditionalCost()
        {
            additionalCost = 0;

            // Add cost for extra shots
            additionalCost += addShot * 20; // Each shot costs ₱20

            // Add cost for flavor
            if (!string.IsNullOrEmpty(milkChoice))
            {
                additionalCost += 20; // Each flavor costs ₱20
            }

            // Update total price display
            decimal totalPrice = basePrice + additionalCost;
            labelOrderSummary.Text = $"Total: ₱{totalPrice}";
        }
        // Set sugar level based on the radio button selected
        private void lvl100_CheckedChanged(object sender, EventArgs e)
        {
            if (lvl100.Checked)
            {
                sugarLevel = "100% Sugar";
            }
        }

        private void lvl80_CheckedChanged(object sender, EventArgs e)
        {
            if (lvl80.Checked)
            {
                sugarLevel = "80% Sugar";
            }
        }

        private void lvl60_CheckedChanged(object sender, EventArgs e)
        {
            if (lvl60.Checked)
            {
                sugarLevel = "60% Sugar";
            }
        }

        private void lvl40_CheckedChanged(object sender, EventArgs e)
        {
            if (lvl40.Checked)
            {
                sugarLevel = "40% Sugar";
            }
        }

        private void lvl20_CheckedChanged(object sender, EventArgs e)
        {
            if (lvl20.Checked)
            {
                sugarLevel = "20% Sugar";
            }
        }

        private void lvl0_CheckedChanged(object sender, EventArgs e)
        {
            if (lvl0.Checked)
            {
                sugarLevel = "No Sugar";
            }
        }

        // When user clicks the button to go to the Cart form
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(sugarLevel))
            {
                MessageBox.Show("Please select a sugar level.");
                return;
            }

            // Build the order summary with all selections
            string orderSummary = $"{coffeeName} - {size} - Sugar Level: {sugarLevel}\n";
            orderSummary += $"Milk: {milkChoice}\n";
            orderSummary += $"Esspreso: {addShot}\n";
            orderSummary += $"DineInOrTakeout: {DineInOrTakeout}\n";
            orderSummary += $"Special Instructions: {customInstructions}\n";
            orderSummary += $"Total Price: ₱{(basePrice + additionalCost) * quantityy}\n";

            Cart cartForm = Application.OpenForms.OfType<Cart>().FirstOrDefault();

            if (cartForm == null)
            {
                cartForm = new Cart(orderSummary);
                cartForm.Show();
            }
            else
            {
                cartForm.AddOrder(orderSummary);
            }

            this.Close();



        }

        private void label1_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Order orderform = new Order();
            orderform.Show();
            this.Hide();
        }

        private void Custom_Click(object sender, EventArgs e)
        {
            Customize customize = new Customize();
            customize.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Cart cart = new Cart();
            cart.Show();
            this.Hide();
        }

        private void Customize_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void labelOrderSummary_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

            if (caramel.Checked)
            {
                milkChoice = "Caramel";

            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void customInstruction_TextChanged(object sender, EventArgs e)
        {
            customInstructions = customInstruction.Text;
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
            if (vanilla.Checked)
            {
                milkChoice = "vanilla";
            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (almondMilk.Checked)
            {
                milkChoice = "Almond Milk";
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            if (extra1.Checked)
            {
                addShot = 1;
            }
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (extra2.Checked)
            {
                addShot = 2;
            }
        }

        private void extra4_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (dineIn.Checked)
            {
                DineInOrTakeout = "Dine-In";
            }
        }

        private void takeout_CheckedChanged(object sender, EventArgs e)
        {
            if (takeout.Checked)
            {
                DineInOrTakeout = "Take-Out";
            }
        }

        private void oatMilk_CheckedChanged(object sender, EventArgs e)
        {
            if (oatMilk.Checked)
            {
                milkChoice = "Oat Milk";
            }
        }

        private void groupBox5_Enter(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void quantity_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(labelOrderSummary.Text, out int quantity) && quantity > 0)
            {
                quantityy = quantity;
            }
            else
            {
                MessageBox.Show("Please enter a valid quantity (greater than 0).");
                

            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            customInstructions = customInstruction.Text;
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton6_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton4_CheckedChanged_1(object sender, EventArgs e)
        {
            if (extra3.Checked)
            {
                addShot = 3;
            }
        }

        private void radioButton5_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void radioButton9_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}



