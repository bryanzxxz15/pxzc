﻿using System;

namespace WindowsFormsApp3
{
    internal class DashboardForm
    {
        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}