﻿CREATE TABLE users
(
	id INT PRIMARY KEY IDENTITY(1,1),
	email VARCHAR (MAX) NULL,
	password VARCHAR (MAX) NULL,
	role VARCHAR(MAX) NULL,
	status VARCHAR(MAX)NULL,
	date_reg DATE NULL
);

SELECT * FROM users 

INSERT INTO users(email, password, role, status, date_reg) VALUES ('admin1', 'admin123', 'admin', 'Active', '11-11-2024');