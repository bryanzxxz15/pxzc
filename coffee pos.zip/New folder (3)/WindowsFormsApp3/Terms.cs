﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Terms : Form
    {
        public Terms()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create an instance of the Terms form
            Register registerForm = new Register();

            // Show the Terms form
            registerForm.Show();

            // Optionally, hide the current Register form
            this.Hide();
        }
    }
}