﻿namespace WindowsFormsApp3
{
    partial class Customize
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.Custom = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lvl100 = new System.Windows.Forms.RadioButton();
            this.lvl80 = new System.Windows.Forms.RadioButton();
            this.lvl60 = new System.Windows.Forms.RadioButton();
            this.lvl0 = new System.Windows.Forms.RadioButton();
            this.lvl20 = new System.Windows.Forms.RadioButton();
            this.lvl40 = new System.Windows.Forms.RadioButton();
            this.labelOrderSummary = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.flavor = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.customInstruction = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.extra3 = new System.Windows.Forms.RadioButton();
            this.extra2 = new System.Windows.Forms.RadioButton();
            this.extra1 = new System.Windows.Forms.RadioButton();
            this.vanilla = new System.Windows.Forms.RadioButton();
            this.caramel = new System.Windows.Forms.RadioButton();
            this.almondMilk = new System.Windows.Forms.RadioButton();
            this.oatMilk = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dineIn = new System.Windows.Forms.RadioButton();
            this.takeout = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton9 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(146)))), ((int)(((byte)(108)))), ((int)(((byte)(21)))));
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.Custom);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1274, 94);
            this.panel1.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(375, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Cart";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // Custom
            // 
            this.Custom.AutoSize = true;
            this.Custom.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Custom.Location = new System.Drawing.Point(248, 53);
            this.Custom.Name = "Custom";
            this.Custom.Size = new System.Drawing.Size(118, 24);
            this.Custom.TabIndex = 2;
            this.Custom.Text = "Customize";
            this.Custom.Click += new System.EventHandler(this.Custom_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(164, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Order";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(81, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Home";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(86, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(150, 24);
            this.label5.TabIndex = 5;
            this.label5.Text = "Your Order is ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(587, 156);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(121, 24);
            this.label7.TabIndex = 8;
            this.label7.Text = "Sugar Level";
            // 
            // lvl100
            // 
            this.lvl100.AutoSize = true;
            this.lvl100.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lvl100.Location = new System.Drawing.Point(16, 16);
            this.lvl100.Margin = new System.Windows.Forms.Padding(2);
            this.lvl100.Name = "lvl100";
            this.lvl100.Size = new System.Drawing.Size(51, 17);
            this.lvl100.TabIndex = 10;
            this.lvl100.TabStop = true;
            this.lvl100.Text = "100%";
            this.lvl100.UseVisualStyleBackColor = true;
            this.lvl100.CheckedChanged += new System.EventHandler(this.lvl100_CheckedChanged);
            // 
            // lvl80
            // 
            this.lvl80.AutoSize = true;
            this.lvl80.Location = new System.Drawing.Point(16, 37);
            this.lvl80.Margin = new System.Windows.Forms.Padding(2);
            this.lvl80.Name = "lvl80";
            this.lvl80.Size = new System.Drawing.Size(45, 17);
            this.lvl80.TabIndex = 12;
            this.lvl80.TabStop = true;
            this.lvl80.Text = "80%";
            this.lvl80.UseVisualStyleBackColor = true;
            this.lvl80.CheckedChanged += new System.EventHandler(this.lvl80_CheckedChanged);
            // 
            // lvl60
            // 
            this.lvl60.AutoSize = true;
            this.lvl60.Location = new System.Drawing.Point(16, 58);
            this.lvl60.Margin = new System.Windows.Forms.Padding(2);
            this.lvl60.Name = "lvl60";
            this.lvl60.Size = new System.Drawing.Size(45, 17);
            this.lvl60.TabIndex = 14;
            this.lvl60.TabStop = true;
            this.lvl60.Text = "60%";
            this.lvl60.UseVisualStyleBackColor = true;
            this.lvl60.CheckedChanged += new System.EventHandler(this.lvl60_CheckedChanged);
            // 
            // lvl0
            // 
            this.lvl0.AutoSize = true;
            this.lvl0.Location = new System.Drawing.Point(88, 58);
            this.lvl0.Margin = new System.Windows.Forms.Padding(2);
            this.lvl0.Name = "lvl0";
            this.lvl0.Size = new System.Drawing.Size(39, 17);
            this.lvl0.TabIndex = 17;
            this.lvl0.TabStop = true;
            this.lvl0.Text = "0%";
            this.lvl0.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lvl0.UseVisualStyleBackColor = true;
            this.lvl0.CheckedChanged += new System.EventHandler(this.lvl0_CheckedChanged);
            // 
            // lvl20
            // 
            this.lvl20.AutoSize = true;
            this.lvl20.Location = new System.Drawing.Point(88, 37);
            this.lvl20.Margin = new System.Windows.Forms.Padding(2);
            this.lvl20.Name = "lvl20";
            this.lvl20.Size = new System.Drawing.Size(45, 17);
            this.lvl20.TabIndex = 16;
            this.lvl20.TabStop = true;
            this.lvl20.Text = "20%";
            this.lvl20.UseVisualStyleBackColor = true;
            this.lvl20.CheckedChanged += new System.EventHandler(this.lvl20_CheckedChanged);
            // 
            // lvl40
            // 
            this.lvl40.AutoSize = true;
            this.lvl40.Location = new System.Drawing.Point(88, 16);
            this.lvl40.Margin = new System.Windows.Forms.Padding(2);
            this.lvl40.Name = "lvl40";
            this.lvl40.Size = new System.Drawing.Size(45, 17);
            this.lvl40.TabIndex = 15;
            this.lvl40.TabStop = true;
            this.lvl40.Text = "40%";
            this.lvl40.UseVisualStyleBackColor = true;
            this.lvl40.CheckedChanged += new System.EventHandler(this.lvl40_CheckedChanged);
            // 
            // labelOrderSummary
            // 
            this.labelOrderSummary.AutoSize = true;
            this.labelOrderSummary.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOrderSummary.Location = new System.Drawing.Point(37, 157);
            this.labelOrderSummary.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelOrderSummary.Name = "labelOrderSummary";
            this.labelOrderSummary.Size = new System.Drawing.Size(105, 24);
            this.labelOrderSummary.TabIndex = 18;
            this.labelOrderSummary.Text = "Your order:";
            this.labelOrderSummary.Click += new System.EventHandler(this.labelOrderSummary_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(644, 641);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(73, 30);
            this.button1.TabIndex = 19;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(430, 115);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 24);
            this.label3.TabIndex = 21;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(376, 157);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 48);
            this.label6.TabIndex = 23;
            this.label6.Text = "       Extra \r\nEspresso shot";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(377, 310);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 24);
            this.label8.TabIndex = 26;
            // 
            // flavor
            // 
            this.flavor.AutoSize = true;
            this.flavor.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.flavor.Location = new System.Drawing.Point(384, 297);
            this.flavor.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.flavor.Name = "flavor";
            this.flavor.Size = new System.Drawing.Size(127, 24);
            this.flavor.TabIndex = 33;
            this.flavor.Text = "Type Of Milk";
            this.flavor.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(799, 157);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(198, 24);
            this.label10.TabIndex = 38;
            this.label10.Text = "Custom Instructions ";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // customInstruction
            // 
            this.customInstruction.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.customInstruction.Location = new System.Drawing.Point(803, 200);
            this.customInstruction.Margin = new System.Windows.Forms.Padding(2);
            this.customInstruction.Name = "customInstruction";
            this.customInstruction.Size = new System.Drawing.Size(168, 23);
            this.customInstruction.TabIndex = 40;
            this.customInstruction.TextChanged += new System.EventHandler(this.customInstruction_TextChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.extra3);
            this.groupBox1.Controls.Add(this.extra2);
            this.groupBox1.Controls.Add(this.extra1);
            this.groupBox1.Location = new System.Drawing.Point(373, 206);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(134, 67);
            this.groupBox1.TabIndex = 41;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // extra3
            // 
            this.extra3.AutoSize = true;
            this.extra3.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.extra3.Location = new System.Drawing.Point(50, 40);
            this.extra3.Margin = new System.Windows.Forms.Padding(2);
            this.extra3.Name = "extra3";
            this.extra3.Size = new System.Drawing.Size(31, 17);
            this.extra3.TabIndex = 44;
            this.extra3.TabStop = true;
            this.extra3.Text = "3";
            this.extra3.UseVisualStyleBackColor = true;
            this.extra3.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged_1);
            // 
            // extra2
            // 
            this.extra2.AutoSize = true;
            this.extra2.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.extra2.Location = new System.Drawing.Point(81, 16);
            this.extra2.Margin = new System.Windows.Forms.Padding(2);
            this.extra2.Name = "extra2";
            this.extra2.Size = new System.Drawing.Size(31, 17);
            this.extra2.TabIndex = 43;
            this.extra2.TabStop = true;
            this.extra2.Text = "2";
            this.extra2.UseVisualStyleBackColor = true;
            this.extra2.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // extra1
            // 
            this.extra1.AutoSize = true;
            this.extra1.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.extra1.Location = new System.Drawing.Point(23, 16);
            this.extra1.Margin = new System.Windows.Forms.Padding(2);
            this.extra1.Name = "extra1";
            this.extra1.Size = new System.Drawing.Size(31, 17);
            this.extra1.TabIndex = 42;
            this.extra1.TabStop = true;
            this.extra1.Text = "1";
            this.extra1.UseVisualStyleBackColor = false;
            this.extra1.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // vanilla
            // 
            this.vanilla.AutoSize = true;
            this.vanilla.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.vanilla.Location = new System.Drawing.Point(10, 16);
            this.vanilla.Margin = new System.Windows.Forms.Padding(2);
            this.vanilla.Name = "vanilla";
            this.vanilla.Size = new System.Drawing.Size(56, 17);
            this.vanilla.TabIndex = 34;
            this.vanilla.TabStop = true;
            this.vanilla.Text = "Vanilla";
            this.vanilla.UseVisualStyleBackColor = true;
            this.vanilla.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // caramel
            // 
            this.caramel.AutoSize = true;
            this.caramel.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.caramel.Location = new System.Drawing.Point(89, 16);
            this.caramel.Margin = new System.Windows.Forms.Padding(2);
            this.caramel.Name = "caramel";
            this.caramel.Size = new System.Drawing.Size(63, 17);
            this.caramel.TabIndex = 36;
            this.caramel.TabStop = true;
            this.caramel.Text = "Caramel";
            this.caramel.UseVisualStyleBackColor = true;
            this.caramel.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // almondMilk
            // 
            this.almondMilk.AutoSize = true;
            this.almondMilk.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.almondMilk.Location = new System.Drawing.Point(4, 46);
            this.almondMilk.Margin = new System.Windows.Forms.Padding(2);
            this.almondMilk.Name = "almondMilk";
            this.almondMilk.Size = new System.Drawing.Size(82, 17);
            this.almondMilk.TabIndex = 37;
            this.almondMilk.TabStop = true;
            this.almondMilk.Text = "Almond Milk";
            this.almondMilk.UseVisualStyleBackColor = true;
            this.almondMilk.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // oatMilk
            // 
            this.oatMilk.AutoSize = true;
            this.oatMilk.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.oatMilk.Location = new System.Drawing.Point(92, 46);
            this.oatMilk.Margin = new System.Windows.Forms.Padding(2);
            this.oatMilk.Name = "oatMilk";
            this.oatMilk.Size = new System.Drawing.Size(64, 17);
            this.oatMilk.TabIndex = 39;
            this.oatMilk.TabStop = true;
            this.oatMilk.Text = "Oat Milk";
            this.oatMilk.UseVisualStyleBackColor = true;
            this.oatMilk.CheckedChanged += new System.EventHandler(this.oatMilk_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.vanilla);
            this.groupBox2.Controls.Add(this.caramel);
            this.groupBox2.Controls.Add(this.almondMilk);
            this.groupBox2.Controls.Add(this.oatMilk);
            this.groupBox2.Location = new System.Drawing.Point(354, 323);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(168, 94);
            this.groupBox2.TabIndex = 46;
            this.groupBox2.TabStop = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lvl100);
            this.groupBox3.Controls.Add(this.lvl80);
            this.groupBox3.Controls.Add(this.lvl60);
            this.groupBox3.Controls.Add(this.lvl40);
            this.groupBox3.Controls.Add(this.lvl20);
            this.groupBox3.Controls.Add(this.lvl0);
            this.groupBox3.Location = new System.Drawing.Point(573, 190);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(150, 81);
            this.groupBox3.TabIndex = 47;
            this.groupBox3.TabStop = false;
            // 
            // dineIn
            // 
            this.dineIn.AutoSize = true;
            this.dineIn.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.dineIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dineIn.Location = new System.Drawing.Point(37, 16);
            this.dineIn.Margin = new System.Windows.Forms.Padding(2);
            this.dineIn.Name = "dineIn";
            this.dineIn.Size = new System.Drawing.Size(70, 21);
            this.dineIn.TabIndex = 46;
            this.dineIn.TabStop = true;
            this.dineIn.Text = "Dine In";
            this.dineIn.UseVisualStyleBackColor = false;
            this.dineIn.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // takeout
            // 
            this.takeout.AutoSize = true;
            this.takeout.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.takeout.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.takeout.Location = new System.Drawing.Point(37, 59);
            this.takeout.Margin = new System.Windows.Forms.Padding(2);
            this.takeout.Name = "takeout";
            this.takeout.Size = new System.Drawing.Size(86, 21);
            this.takeout.TabIndex = 48;
            this.takeout.TabStop = true;
            this.takeout.Text = "Take-Out";
            this.takeout.UseVisualStyleBackColor = false;
            this.takeout.CheckedChanged += new System.EventHandler(this.takeout_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dineIn);
            this.groupBox4.Controls.Add(this.takeout);
            this.groupBox4.Location = new System.Drawing.Point(803, 263);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox4.Size = new System.Drawing.Size(142, 81);
            this.groupBox4.TabIndex = 49;
            this.groupBox4.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(595, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(143, 24);
            this.label9.TabIndex = 50;
            this.label9.Text = "CUSTOMIZE ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(326, 207);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(46, 24);
            this.label11.TabIndex = 51;
            this.label11.Text = "₱20";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(302, 320);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 24);
            this.label12.TabIndex = 52;
            this.label12.Text = "₱20";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(569, 297);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(209, 20);
            this.label13.TabIndex = 53;
            this.label13.Text = "Ice Level (For ice coffee)";
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Location = new System.Drawing.Point(26, 61);
            this.radioButton6.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(62, 17);
            this.radioButton6.TabIndex = 17;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "Regular";
            this.radioButton6.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.radioButton6.UseVisualStyleBackColor = true;
            this.radioButton6.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged_1);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(26, 37);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(65, 17);
            this.radioButton3.TabIndex = 14;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Less Ice";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(26, 16);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(80, 17);
            this.radioButton2.TabIndex = 12;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "Regular Ice";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.radioButton1.Location = new System.Drawing.Point(26, 85);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(57, 17);
            this.radioButton1.TabIndex = 10;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "No Ice";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged_1);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.radioButton1);
            this.groupBox5.Controls.Add(this.radioButton2);
            this.groupBox5.Controls.Add(this.radioButton3);
            this.groupBox5.Controls.Add(this.radioButton6);
            this.groupBox5.Location = new System.Drawing.Point(573, 323);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox5.Size = new System.Drawing.Size(176, 110);
            this.groupBox5.TabIndex = 48;
            this.groupBox5.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(304, 463);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(46, 24);
            this.label14.TabIndex = 55;
            this.label14.Text = "₱20";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.radioButton4);
            this.groupBox6.Controls.Add(this.radioButton5);
            this.groupBox6.Controls.Add(this.radioButton7);
            this.groupBox6.Location = new System.Drawing.Point(351, 462);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox6.Size = new System.Drawing.Size(171, 133);
            this.groupBox6.TabIndex = 54;
            this.groupBox6.TabStop = false;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.radioButton4.Location = new System.Drawing.Point(22, 87);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(111, 30);
            this.radioButton4.TabIndex = 44;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Cinnamon Powder\n\n";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.radioButton5.Location = new System.Drawing.Point(22, 53);
            this.radioButton5.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(119, 30);
            this.radioButton5.TabIndex = 43;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Chocolate Sprinkles\n\n";
            this.radioButton5.UseVisualStyleBackColor = true;
            this.radioButton5.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged_1);
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.radioButton7.Location = new System.Drawing.Point(23, 16);
            this.radioButton7.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(101, 17);
            this.radioButton7.TabIndex = 42;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "Whipped Cream";
            this.radioButton7.UseVisualStyleBackColor = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(375, 436);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(98, 24);
            this.label15.TabIndex = 56;
            this.label15.Text = "Toppings";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(567, 449);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label16.Size = new System.Drawing.Size(138, 20);
            this.label16.TabIndex = 57;
            this.label16.Text = "Coffee Strength";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.radioButton8);
            this.groupBox7.Controls.Add(this.radioButton9);
            this.groupBox7.Controls.Add(this.radioButton10);
            this.groupBox7.Location = new System.Drawing.Point(567, 471);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox7.Size = new System.Drawing.Size(171, 108);
            this.groupBox7.TabIndex = 55;
            this.groupBox7.TabStop = false;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.radioButton8.Location = new System.Drawing.Point(22, 87);
            this.radioButton8.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(56, 17);
            this.radioButton8.TabIndex = 44;
            this.radioButton8.Text = "Strong";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton9
            // 
            this.radioButton9.AutoSize = true;
            this.radioButton9.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.radioButton9.Location = new System.Drawing.Point(22, 53);
            this.radioButton9.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton9.Name = "radioButton9";
            this.radioButton9.Size = new System.Drawing.Size(62, 17);
            this.radioButton9.TabIndex = 43;
            this.radioButton9.Text = "Regular";
            this.radioButton9.UseVisualStyleBackColor = true;
            this.radioButton9.CheckedChanged += new System.EventHandler(this.radioButton9_CheckedChanged);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.radioButton10.Location = new System.Drawing.Point(23, 16);
            this.radioButton10.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(48, 17);
            this.radioButton10.TabIndex = 42;
            this.radioButton10.TabStop = true;
            this.radioButton10.Text = "Light";
            this.radioButton10.UseVisualStyleBackColor = false;
            // 
            // Customize
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(195)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(1274, 705);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.customInstruction);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.flavor);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.labelOrderSummary);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Customize";
            this.Load += new System.EventHandler(this.Customize_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label Custom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton lvl100;
        private System.Windows.Forms.RadioButton lvl80;
        private System.Windows.Forms.RadioButton lvl60;
        private System.Windows.Forms.RadioButton lvl0;
        private System.Windows.Forms.RadioButton lvl20;
        private System.Windows.Forms.RadioButton lvl40;
        private System.Windows.Forms.Label labelOrderSummary;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label flavor;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox customInstruction;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton extra2;
        private System.Windows.Forms.RadioButton extra1;
        private System.Windows.Forms.RadioButton vanilla;
        private System.Windows.Forms.RadioButton caramel;
        private System.Windows.Forms.RadioButton almondMilk;
        private System.Windows.Forms.RadioButton oatMilk;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton dineIn;
        private System.Windows.Forms.RadioButton takeout;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.RadioButton extra3;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton9;
        private System.Windows.Forms.RadioButton radioButton10;
    }
}