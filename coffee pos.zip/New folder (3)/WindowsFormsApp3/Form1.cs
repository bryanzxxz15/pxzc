﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {

        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus Laptop\Documents\CafeDataBase.mdf"";Integrated Security=True;Connect Timeout=30");


        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void login_Email_TextChanged(object sender, EventArgs e)
        {

        }

        private void login_Password_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (string.IsNullOrWhiteSpace(login_Email.Text) || string.IsNullOrWhiteSpace(login_Password.Text))
            {
                MessageBox.Show("Please enter both Email and Password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
               
                connect.Open();

                
                string query = "SELECT * FROM users WHERE email = @Email AND password = @Password";
                using (SqlCommand cmd = new SqlCommand(query, connect))
                {
                    cmd.Parameters.AddWithValue("@Email", login_Email.Text.Trim());
                    cmd.Parameters.AddWithValue("@Password", login_Password.Text.Trim());

                    
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    if (table.Rows.Count == 1) 
                    {
                        string userRole = table.Rows[0]["role"].ToString(); 

                        MessageBox.Show($"Welcome, {userRole}!", "Login Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);


                        Dashboard dashboard = new Dashboard();
                        dashboard.Show();

                        this.Hide();
                    }
                    else 
                    {
                        MessageBox.Show("Invalid Email or Password. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                
                connect.Close();
            }
        }

        private void login_showPassword_CheckedChanged(object sender, EventArgs e)
        {
            
            login_Password.PasswordChar = login_showPassword.Checked ? '\0' : '*';
        }

        private void login_Register_Click(object sender, EventArgs e)
        {
            
            Register regForm = new Register();
            regForm.Show();

            this.Hide();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ForgotPassword forgotPasswordForm = new ForgotPassword();
            forgotPasswordForm.Show();
            this.Hide();

        }

        private void x_button_Click(object sender, EventArgs e)
        {
            // Show a message box with "Yes" and "No" options
            DialogResult result = MessageBox.Show("Are you sure you want to close the application?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // Check if the user clicked "Yes"
            if (result == DialogResult.Yes)
            {
                // Close the application
                Application.Exit();
            }
        }
    }
}
