﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Customize : Form
    {
        private string coffeeName;
        private string size;

        public Customize(string coffeeName, string size)
        {
            InitializeComponent();

            this.coffeeName = coffeeName;
            this.size = size;

            labelOrderSummary.Text = $"Your order: {coffeeName} - {size}";
        }
    }
}