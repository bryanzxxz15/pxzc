﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Cart : Form
    {
        private List<string> orders = new List<string>();
        private decimal grandTotal = 0;

        public Cart(List<string> orderDetails, decimal totalPrice) : this()
        {
            orders = orderDetails ?? new List<string>();
            grandTotal = totalPrice;
            UpdateOrderSummary();
        }

        public Cart()
        {
            InitializeComponent();
            UpdateOrderSummary();
        }

        public Cart(string orderDetails) : this()
        {

            AddOrder(orderDetails);
            labelOrderSummary.Text = orderDetails;
        }
        public void AddOrder(string orderDetails)
        {
            orders.Add(orderDetails);

            // Extract the price from the ord  er details to update the grand total
            string[] lines = orderDetails.Split('\n');
            string priceLine = lines.LastOrDefault();  // Get the last line (Total Price)

            if (priceLine != null)
            {
                decimal price = 0;
                if (priceLine.StartsWith("Total Price: ₱"))
                {
                    price = decimal.Parse(priceLine.Replace("Total Price: ₱", "").Trim());
                    grandTotal += price;

                }
            }
            UpdateOrderSummary();

        }
        private void UpdateOrderSummary()
        {
            labelOrderSummary.Text = string.Join("\n\n", orders);
            labelOrderSummary.Text += $"\n\nGrand Total: ₱{grandTotal}";
        }

       

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();

            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Order order = new Order();
            order.Show();
            this.Hide();
        }

        private void Custom_Click(object sender, EventArgs e)
        {
            Customize customize = new Customize();
            customize.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (orders.Count == 0)
            {
                MessageBox.Show("Your cart is empty. Add items before generating a receipt.", "Cart Empty");
                return;
            }


            // Generate receipt content
            string receipt = GenerateReceipt();

            // Display the receipt in a MessageBox or create a new Receipt form
            MessageBox.Show(receipt, "Receipt");

            MessageBox.Show($"Thank you for your order!\n\n{labelOrderSummary.Text}", "Checkout");
            orders.Clear();
            grandTotal = 0;
            UpdateOrderSummary();
        }

        private string GenerateReceipt()
        {
            StringBuilder receiptBuilder = new StringBuilder();
            receiptBuilder.AppendLine("======= Receipt =======");
            receiptBuilder.AppendLine($"Date: {DateTime.Now}");
            receiptBuilder.AppendLine("-----------------------");

            // Add all orders to the receipt
            foreach (string order in orders)
            {
                receiptBuilder.AppendLine(order);
            }

            receiptBuilder.AppendLine("-----------------------");
            receiptBuilder.AppendLine($"Total Items: {orders.Count}");
            receiptBuilder.AppendLine("=======================");

            return receiptBuilder.ToString();



    }

    private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}   
