﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Order : Form
    {

        private List<string> orders; // Shared list for orders
        private string itemCode;     // Code for the selected drink
        private Dictionary<string, decimal> prices; // Prices for items
        private decimal totalPrice = 0;       
        public Order()
        {
            InitializeComponent();
            InitializePrices(); // Initialize item prices
            orders = new List<string>();

        }
        public Order(List<string> sharedOrders)
        {

            orders = sharedOrders ?? new List<string>();
            InitializePrices();
            orders = sharedOrders ?? new List<string>();
        }

        private void InitializePrices()
        {
            prices = new Dictionary<string, decimal>
            {
                { "MochaM", 70 }, { "MochaL", 90 },
                { "AmericanoM", 70 }, { "AmericanoL", 90 },
                { "MatchaM", 70 }, { "MatchaL", 90 },
                { "LatteM", 70 }, { "LatteL", 90 }
            };
        }

        private void AddOrder(string code, string description)
        {
            if (prices == null || !prices.ContainsKey(code))
            {
                MessageBox.Show("Invalid or missing item code!", "Error");
                return;
            }

            decimal price = prices[code];
            string orderDetails = $"{description} - ₱{price}";
            orders.Add(orderDetails);
            totalPrice += price;

            MessageBox.Show($"{orderDetails} has been added to your cart!", "Order Added");
        }




        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Dashboard dashboardform = new Dashboard();
            dashboardform.Show();

            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            if (!label2.Enabled)
            {
                return;
            }
            Cart cartForm = new Cart(orders, totalPrice); // Pass orders and total price to Cart form
            cartForm.Show();
            this.Hide();


        }

        private void Order_Load(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void vScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Customize customize = new Customize();
            customize.Show();

            this.Hide();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void coffeeAmerikanoM_Click(object sender, EventArgs e)
        {

        }

        private void mochaM_Click(object sender, EventArgs e)
        {
            AddOrder("MochaM", "Mocha - Medium");
            Customize customizeForm = new Customize("MochaM", "Mocha - Medium");
            customizeForm.ShowDialog();
            this.Hide();

        }

        private void mochaL_Click(object sender, EventArgs e)
        {
            AddOrder("MochaL", "Mocha - Large");
            Customize customizeForm = new Customize("MochaL", "Mocha - Large");
            customizeForm.ShowDialog();
            this.Hide();
        }

        private void americanoM_Click(object sender, EventArgs e)
        {

            AddOrder("AmericanoM", "Americano - Medium");
            Customize customizeForm = new Customize("AmericanoM", "Americano - Medium");
            customizeForm.ShowDialog();

            this.Hide();

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void americanoL_Click(object sender, EventArgs e)
        {

            AddOrder("AmericanoL", "Americano - Large");
            Customize customizeForm = new Customize("AmericanoL", "Americano - Large");
            customizeForm.ShowDialog();
            this.Hide();
        }

        private void matchaM_Click(object sender, EventArgs e)
        {

            AddOrder("MatchaM", "Matcha - Large");
            Customize customizeForm = new Customize("Matcha", "Matcha - Medium");
            customizeForm.ShowDialog();
            this.Hide();
        }

        private void matchaL_Click(object sender, EventArgs e)
        {
            AddOrder("MatchaL", "Matcha - Large");
            Customize customizeForm = new Customize("Matcha", "Matcha - Large");
            customizeForm.ShowDialog();
            this.Hide();
        }

        private void latteM_Click(object sender, EventArgs e)
        {
            AddOrder("LatteM", "Latte - Medium");
            Customize customizeForm = new Customize("LatteM", "Latte - Medium");
            customizeForm.ShowDialog();
            this.Hide();
        }

        private void latteL_Click(object sender, EventArgs e)
        {
            AddOrder("LatteM", "Latte - Medium");
            Customize customizeForm = new Customize("LatteL", "Latte - Large");
            customizeForm.ShowDialog();

        }

        private void NavigateToCustomize(string code, string description)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cart cartForm = new Cart(orders, totalPrice); // Pass orders and totalPrice to the Cart form
            cartForm.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }
    }
}