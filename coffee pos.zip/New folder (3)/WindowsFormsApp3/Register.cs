﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace WindowsFormsApp3
{
    public partial class Register : Form
    {

        SqlConnection connect = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\Asus Laptop\Documents\CafeDataBase.mdf"";Integrated Security=True;Connect Timeout=30");


        public Register()
        {
            InitializeComponent();
        }

        private void Register_Load(object sender, EventArgs e)
        {
            
        }

        private void register_loginBtn_Click(object sender, EventArgs e)
        {
            
            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Hide();
        }

        private void register_showPassowrd_CheckedChanged(object sender, EventArgs e)
        {
            
            register_password.PasswordChar = register_showPassowrd.Checked ? '\0' : '*';
            register_cPassword.PasswordChar = register_showPassowrd.Checked ? '\0' : '*';
        }

        private void email_Register_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void register_password_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void register_cPassword_TextChanged(object sender, EventArgs e)
        {
            
        }

        
        public bool emptyFields()
        {
            return string.IsNullOrEmpty(email_Register.Text) ||
                   string.IsNullOrEmpty(register_password.Text) ||
                   string.IsNullOrEmpty(register_cPassword.Text);
        }

        private void register_btn_Click(object sender, EventArgs e)
        {
            // Check if the terms and conditions checkbox is checked
            if (!termsBox.Checked)
            {
                MessageBox.Show("You must agree to the terms and conditions before registering.",
                                "Agreement Required",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;  // Exit the method early if checkbox is not checked
            }

            // Check for empty fields (email and password)
            if (emptyFields())
            {
                MessageBox.Show("Please fill in an email and password.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    connect.Open();

                    // Check if the email is already registered
                    string selectUsername = "SELECT * FROM users WHERE email = @usern";
                    using (SqlCommand checkEmail = new SqlCommand(selectUsername, connect))
                    {
                        checkEmail.Parameters.AddWithValue("@usern", email_Register.Text.Trim());

                        SqlDataAdapter adapter = new SqlDataAdapter(checkEmail);
                        DataTable table = new DataTable();

                        adapter.Fill(table);

                        if (table.Rows.Count >= 1)
                        {
                            MessageBox.Show("Email is already registered.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else if (register_password.Text != register_cPassword.Text)
                        {
                            MessageBox.Show("Passwords do not match.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else if (register_password.Text.Length < 7)
                        {
                            MessageBox.Show("Password must be at least 7 characters long.", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            // Register the user
                            string insertData = "INSERT INTO users (email, password, role, status, date_reg) VALUES (@email, @pass, @role, @status, @date)";
                            DateTime today = DateTime.Today;

                            using (SqlCommand cmd = new SqlCommand(insertData, connect))
                            {
                                cmd.Parameters.AddWithValue("@email", email_Register.Text.Trim());
                                cmd.Parameters.AddWithValue("@pass", register_password.Text.Trim());
                                cmd.Parameters.AddWithValue("@role", "Customer");
                                cmd.Parameters.AddWithValue("@status", "Active");
                                cmd.Parameters.AddWithValue("@date", today);

                                cmd.ExecuteNonQuery();
                                MessageBox.Show("Registered successfully!", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Connection failed: " + ex.Message, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Terms terms = new Terms();
            terms.Show();

            this.Close();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

